import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../ui/custom_app_bar.dart';
import '../ui/top_panel.dart';
import '../ui/sidebar_menu.dart';
import '../ui/widget_panel.dart';
import '../ui/node_panel.dart';
import '../ui/site_panel.dart';
import '../ui/data_panel.dart';
import '../ui/library_panel.dart';

import '../ui/work_area.dart';
import '../ui/property_panel.dart';

import '../models/selected_widget_model.dart';

/// Enum을 사용하여 메뉴 옵션 정의
enum MenuOption {
  Site,
  Widget,
  Node,
  Data,
  Library,
  User,
  Setting,
}

/// Tuple2 클래스 정의 (필요시 패키지 사용 가능)
class Tuple2<T1, T2> {
  final T1 item1;
  final T2 item2;
  Tuple2(this.item1, this.item2);
}

/// 홈 화면을 나타내는 StatefulWidget
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

/// 홈 화면의 상태를 관리하는 클래스
class _HomeScreenState extends State<HomeScreen> {
  String selectedMenu = 'Widget'; // 현재 선택된 메뉴 항목
  Widget currentPanel = WidgetPanel(); // 현재 표시 중인 패널
  double panelWidth = 160.0; // 패널의 현재 너비
  bool isPanelVisible = true; // 패널 표시 여부
  OverlayEntry? guidelineOverlay; // HomeScreen에서 관리할 OverlayEntry
  double _resizeWidth = 200.0; // 가이드라인 초기 너비
  double _resizeHeight = 150.0; // 가이드라인 초기 높이

  // 메뉴 라벨을 Enum으로 매핑
  final Map<String, MenuOption> labelToOptionMap = {
    'Site': MenuOption.Site,
    'Widget': MenuOption.Widget,
    'Node': MenuOption.Node,
    'Data': MenuOption.Data,
    'Library': MenuOption.Library,
    'User': MenuOption.User,
    'Setting': MenuOption.Setting,
  };

  // 패널 매핑
  final Map<MenuOption, Tuple2<Widget, double>> panelMap = {
    MenuOption.Site: Tuple2(const SitePanel(), 400.0),
    MenuOption.Widget: Tuple2(WidgetPanel(), 160.0),
    MenuOption.Node: Tuple2(const NodePanel(), 250.0),
    MenuOption.Data: Tuple2(const DataPanel(), 220.0),
    MenuOption.Library: Tuple2(const LibraryPanel(), 280.0),
    // 다른 패널을 추가할 경우 여기에 매핑 추가
  };

  /// 메뉴 선택 시 호출되는 메소드
  void handleMenuSelection(String menuLabel) {
    MenuOption? selectedOption = labelToOptionMap[menuLabel];
    if (selectedOption == null) {
      // 선택된 메뉴에 해당하는 패널이 없는 경우,
      if (isPanelVisible) {
        setState(() {
          selectedMenu = '';
          isPanelVisible = false;
          currentPanel = Container();
        });
      }
      return;
    }

    // 동일한 메뉴 선택 시 패널 토글
    if (menuLabel == selectedMenu) {
      setState(() {
        if (isPanelVisible) {
          isPanelVisible = false;
        } else {
          panelWidth = panelMap[selectedOption]!.item2;
          isPanelVisible = true;
        }
      });
      return;
    }

    // 다른 메뉴 선택 시 패널 전환
    setState(() {
      selectedMenu = menuLabel;
      panelWidth = panelMap[selectedOption]!.item2;
      currentPanel = panelMap[selectedOption]!.item1;
      isPanelVisible = true;
    });
  }

  /// 가이드라인 오버레이 업데이트
  /*void updateGuidelineOverlay(List<OverlayInfo> overlayInfoList) {
    guidelineOverlay?.remove();
    guidelineOverlay = OverlayEntry(
      builder: (context) {
        return Stack(
          children: overlayInfoList.map((overlayInfo) {
            return Positioned(
              left: overlayInfo.offset.dx,
              top: overlayInfo.offset.dy,
              child: Container(
                width: overlayInfo.size.width,
                height: overlayInfo.size.height,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.red, width: 2),
                ),
                child: Stack(
                    children: [
                      // 리사이즈 핸들 추가 (오른쪽 하단 모서리에)
                      Positioned(
                        right: 0,
                        bottom: 0,
                        child: GestureDetector(
                          onPanUpdate: (details) {
                            setState(() {
                              _resizeWidth += details.delta.dx;
                              _resizeHeight += details.delta.dy;

                              // 최소 크기 제한
                              if (_resizeWidth < 50) _resizeWidth = 50;
                              if (_resizeHeight < 50) _resizeHeight = 50;
                            });
                          },
                          child: Container(
                            width: 20,
                            height: 20,
                            decoration: BoxDecoration(
                              color: Colors.blueAccent,
                              shape: BoxShape.circle,
                              border: Border.all(color: Colors.white, width: 2),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
              ),
            );
          }).toList(),
        );
      },
    );

    Overlay.of(context).insert(guidelineOverlay!);
  }*/
  void updateGuidelineOverlay(List<OverlayInfo> overlayInfoList) {
    // 기존 OverlayEntry 제거
    guidelineOverlay?.remove();
    // 새로운 OverlayEntry 생성
    guidelineOverlay = OverlayEntry(
      builder: (context) {
        return Stack(
          children: overlayInfoList.map((overlayInfo) {
            return Positioned(
              left: overlayInfo.offset.dx,
              top: overlayInfo.offset.dy,
              child: Container(
                width: overlayInfo.size.width,
                height: overlayInfo.size.height,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.red, width: 1),
                ),
                child: Stack(
                  children: [
                    // 리사이즈 핸들 추가 (오른쪽 하단 모서리에)
                    Positioned(
                      right: 0,
                      bottom: 0,
                      child: GestureDetector(
                        onPanUpdate: (details) {
                          final newSize = Size(
                            overlayInfo.size.width + details.delta.dx,
                            overlayInfo.size.height + details.delta.dy,
                          );

                          // 최소 크기 제한
                          if (newSize.width >= 50 && newSize.height >= 50) {
                            final index = overlayInfoList.indexOf(overlayInfo);

                            // 인덱스가 유효한지 확인
                            if (index >= 0 && index < overlayInfoList.length) {
                              // 리스트를 직접 업데이트하고 상태 변경
                              overlayInfoList[index] = overlayInfo.copyWith(size: newSize);

                              // UI 갱신을 최소화하기 위해 즉시 다시 렌더링하지 않음
                              guidelineOverlay?.markNeedsBuild();
                            }
                          }
                        },
                        child: Container(
                          width: 20,
                          height: 20,
                          decoration: BoxDecoration(
                            color: Colors.blueAccent,
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.white, width: 2),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          }).toList(),
        );
      },
    );
    // 새로운 Overlay 삽입
    Overlay.of(context).insert(guidelineOverlay!);
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => SelectedWidgetModel(),
      child: Scaffold(
        appBar: const CustomAppBar(),
        body: Stack(
          children: [
            Column(
              children: [
                const TopPanel(),
                Expanded(
                  child: WorkArea(
                    onUpdateGuideline: (overlayInfoList) {
                      updateGuidelineOverlay(overlayInfoList);
                    },
                  ),
                ),
              ],
            ),
            AnimatedPositioned(
              left: isPanelVisible ? 48.0 : -panelWidth,
              top: 48,
              bottom: 0,
              duration: const Duration(milliseconds: 300),
              curve: Curves.easeInOut,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                width: panelWidth,
                curve: Curves.easeInOut,
                color: Colors.white,
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 300),
                  child: isPanelVisible
                      ? KeyedSubtree(
                          key: ValueKey<String>(selectedMenu),
                          child: currentPanel,
                        )
                      : Container(),
                ),
              ),
            ),
            const Positioned(
              right: 0,
              top: 48,
              bottom: 0,
              child: PropertyPanel(),
            ),
            Positioned(
              top: 48,
              bottom: 0,
              left: 0,
              child: SidebarMenu(
                onMenuButtonPressed: handleMenuSelection,
                selectedMenu: selectedMenu,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    guidelineOverlay?.remove();
    super.dispose();
  }
}
