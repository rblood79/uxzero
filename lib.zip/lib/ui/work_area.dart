import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/selected_widget_model.dart';

import '../widgets/container_widget.dart';
import '../widgets/text_widget.dart';

class WorkArea extends StatefulWidget {
  final Function(List<OverlayInfo>) onUpdateGuideline;

  const WorkArea({super.key, required this.onUpdateGuideline});

  @override
  _WorkAreaState createState() => _WorkAreaState();
}

class _WorkAreaState extends State<WorkArea> {
  // 글로벌 키 맵을 정의하여 각 위젯의 고유한 키를 관리합니다.
  final Map<String, GlobalKey<State<StatefulWidget>>> _globalKeys = {};
  final Map<String, ValueKey<String>> _valueKeys = {}; // 필요 시 사용

  Offset? _dragStartPosition;
  Offset? _dragEndPosition;
  bool _isDragging = true;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        return Center(
          child: Consumer<SelectedWidgetModel>(
            builder: (context, selectedWidgetModel, child) {
              final rootContainer = selectedWidgetModel.rootContainer;

              WidgetsBinding.instance.addPostFrameCallback((_) {
                _updateGuidelineOverlay(selectedWidgetModel);
              });

              return GestureDetector(
                onTap: () {
                  selectedWidgetModel.clearSelection();
                  selectedWidgetModel.selectWidget(rootContainer);
                },
                onPanStart: (details) {
                  setState(() {
                    _dragStartPosition = details.globalPosition;
                    _dragEndPosition = _dragStartPosition;
                    _isDragging = true;
                  });
                },
                onPanUpdate: (details) {
                  setState(() {
                    _dragEndPosition = details.globalPosition;
                  });
                },
                onPanEnd: (details) {
                  setState(() {
                    _isDragging = false;
                    _selectWidgetsInDragArea(selectedWidgetModel);
                    _dragStartPosition = null;
                    _dragEndPosition = null;
                  });
                },
                child: Stack(
                  children: [
                    Container(
                      width: rootContainer.width,
                      height: rootContainer.height,
                      decoration: rootContainer.decoration,
                      child: _buildDragTargetForContainer(
                          rootContainer, selectedWidgetModel),
                    ),
                    if (_isDragging &&
                        _dragStartPosition != null &&
                        _dragEndPosition != null)
                      _buildDragSelectionBox(context),
                  ],
                ),
              );
            },
          ),
        );
      },
    );
  }

  Widget _buildDragSelectionBox(BuildContext context) {
    final renderBox = context.findRenderObject() as RenderBox;
    final localStart = renderBox.globalToLocal(_dragStartPosition!);
    final localEnd = renderBox.globalToLocal(_dragEndPosition!);

    return Positioned.fromRect(
      rect: Rect.fromPoints(localStart, localEnd),
      child: IgnorePointer(
        child: Container(
          decoration: BoxDecoration(
            color: Colors.lightBlue.withOpacity(0.3),
            border: Border.all(color: Colors.lightBlue, width: 1),
          ),
        ),
      ),
    );
  }

  /// 가이드라인 오버레이를 업데이트하는 메서드
  void _updateGuidelineOverlay(SelectedWidgetModel selectedWidgetModel) {
    final selectedWidgets = selectedWidgetModel.selectedWidgetProperties;

    if (widget.onUpdateGuideline != null && selectedWidgets.isNotEmpty) {
      List<OverlayInfo> overlayInfoList = [];

      for (var selectedWidget in selectedWidgets) {
        WidgetProperties? currentWidget = selectedWidget;
        final key = _globalKeys[currentWidget.id];
        if (key != null && key.currentContext != null) {
          final renderBox = key.currentContext!.findRenderObject();
          if (renderBox == null || renderBox is! RenderBox) {
            return;
          }
          final size = renderBox.size;
          final offset = renderBox.localToGlobal(Offset.zero);

          overlayInfoList.add(OverlayInfo(
            properties: currentWidget,
            size: size,
            offset: offset,
          ));
        }
      }

      widget.onUpdateGuideline(overlayInfoList);
    }
  }

  /// 드래그 영역 내의 위젯을 선택하는 메서드
  void _selectWidgetsInDragArea(SelectedWidgetModel selectedWidgetModel) {
    if (_dragStartPosition == null || _dragEndPosition == null) return;

    final dragArea = Rect.fromPoints(_dragStartPosition!, _dragEndPosition!);
    selectedWidgetModel.clearSelection();

    for (var child in selectedWidgetModel.rootContainer.children) {
      _selectWidgetsInContainer(child, dragArea, selectedWidgetModel);
    }
  }

  /// 컨테이너 내의 위젯을 재귀적으로 선택하는 메서드
  void _selectWidgetsInContainer(
    WidgetProperties container,
    Rect dragArea,
    SelectedWidgetModel selectedWidgetModel,
  ) {
    final key = _globalKeys[container.id];
    if (key != null && key.currentContext != null) {
      final renderBox = key.currentContext!.findRenderObject();
      if (renderBox == null || renderBox is! RenderBox) {
        return;
      }
      final position = renderBox.localToGlobal(Offset.zero);
      final size = renderBox.size;

      final widgetRect = Rect.fromLTWH(
        position.dx,
        position.dy,
        size.width,
        size.height,
      );

      // 드래그 영역 내에 완전히 포함된 위젯만 선택
      if (dragArea.contains(widgetRect.topLeft) &&
          dragArea.contains(widgetRect.bottomRight)) {
        selectedWidgetModel.addToSelection(container);
      }
    }

    for (var child in container.children) {
      _selectWidgetsInContainer(child, dragArea, selectedWidgetModel);
    }
  }

  Widget _buildDragTargetForContainer(
      WidgetProperties properties, SelectedWidgetModel selectedWidgetModel) {
    return DragTarget<Object>(
      onWillAcceptWithDetails: (details) => true,
      onAcceptWithDetails: (details) {
        setState(() {
          if (details.data is TextWidget) {
            // 텍스트 위젯을 추가
            final textWidget = details.data as TextWidget;
            properties.children.add(
              WidgetProperties(
                id: UID.generate(),//DateTime.now().toString(),
                label: textWidget.label,
                width: textWidget.width,
                height: textWidget.height,
                x: 0,
                y: 0,
                decoration: BoxDecoration(
                  color: Colors.white,
                  border: Border.all(
                    color: Colors.grey.shade400,
                    width: 0.0,
                  ),
                ),
                layoutType: LayoutType.column,
                type: WidgetType.text,
                alignment: Alignment.center,
                parent: properties,
              ),
            );
          } else if (details.data is ContainerWidget) {
            // 컨테이너 위젯을 추가
            final containerWidget = details.data as ContainerWidget;
            properties.children.add(
              WidgetProperties(
                id: UID.generate(),//DateTime.now().toString(),
                label: containerWidget.label,
                width: containerWidget.width,
                height: containerWidget.height,
                x: 0,
                y: 0,
                decoration: containerWidget.decoration,
                layoutType: LayoutType.stack,
                type: WidgetType.container,
                parent: properties,
              ),
            );
          }

          selectedWidgetModel.addToHistory();
        });
      },
      builder: (context, candidateData, rejectedData) {
        return Container(
          width: properties.width,
          height: properties.height,
          decoration: properties.decoration,
          child: _buildLayoutWidget(properties, selectedWidgetModel),
        );
      },
    );
  }

  Widget _buildLayoutWidget(
      WidgetProperties properties, SelectedWidgetModel selectedWidgetModel) {
    switch (properties.layoutType) {
      case LayoutType.row:
        return Row(
          mainAxisAlignment: properties.mainAxisAlignment,
          crossAxisAlignment: properties.crossAxisAlignment,
          children: _buildChildWidgets(properties, selectedWidgetModel),
        );
      case LayoutType.column:
        return Column(
          mainAxisAlignment: properties.mainAxisAlignment,
          crossAxisAlignment: properties.crossAxisAlignment,
          children: _buildChildWidgets(properties, selectedWidgetModel),
        );
      case LayoutType.stack:
        return Stack(
          children: _buildChildWidgets(properties, selectedWidgetModel),
        );
      case LayoutType.grid:
        return GridView.count(
          crossAxisCount: 2,
          children: _buildChildWidgets(properties, selectedWidgetModel),
        );
      case LayoutType.wrap:
        return Wrap(
          alignment: WrapAlignment.start,
          children: _buildChildWidgets(properties, selectedWidgetModel),
        );
      case LayoutType.list:
        return ListView(
          children: _buildChildWidgets(properties, selectedWidgetModel),
        );
      default:
        return const SizedBox();
    }
  }

  List<Widget> _buildChildWidgets(WidgetProperties parentProperties,
      SelectedWidgetModel selectedWidgetModel) {
    return parentProperties.children.map((childProperties) {
      bool isSelected = selectedWidgetModel.selectedWidgetProperties
          .contains(childProperties);

      if (!_globalKeys.containsKey(childProperties.id) &&
          (childProperties.type == WidgetType.container ||
              childProperties.type == WidgetType.text)) {
        _globalKeys[childProperties.id] = GlobalKey();
      }

      if (!_valueKeys.containsKey(childProperties.id) &&
          childProperties.type != WidgetType.container &&
          childProperties.type != WidgetType.text) {
        _valueKeys[childProperties.id] = ValueKey(childProperties.id);
      }

      Widget childWidget = GestureDetector(
        onTap: () {
          selectedWidgetModel.clearSelection();
          selectedWidgetModel.selectWidget(childProperties);
        },
        onLongPress: () {
          selectedWidgetModel.selectWidget(childProperties);
          selectedWidgetModel.deleteSelectedWidget();
        },
        child: DragTarget<Object>(
          onWillAcceptWithDetails: (data) => true,
          onAcceptWithDetails: (data) {
            setState(() {
              if (data.data is TextWidget) {
                final textWidget = data.data as TextWidget;
                childProperties.children.add(
                  WidgetProperties(
                    id: DateTime.now().toString(),
                    label: textWidget.label,
                    width: textWidget.width,
                    height: textWidget.height,
                    x: 0,
                    y: 0,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(
                        color: Colors.grey.shade400,
                        width: 0.0,
                      ),
                    ),
                    layoutType: LayoutType.column,
                    type: WidgetType.text,
                    alignment: Alignment.center,
                    parent: childProperties,
                  ),
                );
              } else if (data.data is ContainerWidget) {
                final containerWidget = data.data as ContainerWidget;
                childProperties.children.add(
                  WidgetProperties(
                    id: DateTime.now().toString(),
                    label: containerWidget.label,
                    width: containerWidget.width,
                    height: containerWidget.height,
                    x: 0,
                    y: 0,
                    decoration: containerWidget.decoration,
                    layoutType: LayoutType.stack,
                    type: WidgetType.container,
                    parent: childProperties,
                  ),
                );
              }
              selectedWidgetModel.addToHistory();
            });
          },
          builder: (context, candidateData, rejectedData) {
            return Container(
              key: _globalKeys.containsKey(childProperties.id)
                  ? _globalKeys[childProperties.id]
                  : _valueKeys[childProperties.id],
              width: childProperties.width,
              height: childProperties.height,
              decoration: childProperties.decoration,
              child: childProperties.type == WidgetType.text
                  ? Align(
                      alignment: childProperties.alignment ?? Alignment.center,
                      child: Text(
                        childProperties.label,
                        textAlign:
                            childProperties.textAlign ?? TextAlign.center,
                        style: TextStyle(
                          fontSize: childProperties.fontSize ?? 12.0,
                          color: Colors.black,
                        ),
                      ),
                    )
                  : _buildDragTargetForContainer(
                      childProperties, selectedWidgetModel),
            );
          },
        ),
      );

      if (parentProperties.layoutType == LayoutType.row ||
          parentProperties.layoutType == LayoutType.column) {
        return Expanded(
          flex: childProperties.flex,
          child: childWidget,
        );
      }

      return childWidget;
    }).toList();
  }

}
